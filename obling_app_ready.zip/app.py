# Indsæt din ChatGPT-genererede kode her
